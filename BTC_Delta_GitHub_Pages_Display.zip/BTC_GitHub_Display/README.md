# BTC Delta Option Intelligence — GitHub Pages

This is a BTC-only, analysis/display dashboard using Delta Exchange public market-data APIs and public WebSocket.

## GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html` and this `README.md` to the repository root.
3. GitHub → Settings → Pages → Deploy from branch → `main` → `/ (root)` → Save.
4. Open the generated Pages URL in Chrome.

## Live-feed behavior
- BTCUSD price: WebSocket + REST fallback.
- Selected BTC option expiry chain: REST snapshot + WebSocket ticker updates.
- Every strike remains visible and recalculates continuously.
- Expiry ranking is refreshed from available live expiries.
- WebSocket automatically reconnects with backoff.
- REST snapshots retry automatically if the socket is unavailable.
- WebSocket heartbeat ping is sent periodically.
- No API key or secret is embedded.
- No order execution is included.

## Important
The dashboard depends on Delta Exchange public endpoints being reachable from the browser and on their current CORS/network policy. If a browser/network blocks direct REST requests from GitHub Pages, a server-side proxy is required; GitHub Pages itself cannot run that proxy.
